

<?php if(request()->is('/')): ?>
<section class="section-7">
    <div class="div-block-124">
        <div class="div-block-122">
            <div class="div-block-119"><img
                    src="https://uploads-ssl.webflow.com/65129d80ea060cc3955c1aff/651a9ebfa3b15ffbad3d1dcf_Previssime%20logo%20writed.png"
                    loading="lazy" width="90" alt="" class="image-49" /></div>
            <div class="text-block-73">© 2020 - Previssime</div>
        </div>
        <div class="div-block-121">
            <div class="text-block-75">Structure</div>
            <div class="text-block-74">Home</div>
            <div class="text-block-74">Tarif</div>
            <div class="text-block-74">Fonctionnalités</div>
            <div class="text-block-74">Contact</div>
        </div>
        <div class="div-block-123">
            <div class="text-block-75 m1">Contact</div>
            <div class="text-block-74 m1">info@previssime.ch</div>
            <div class="div-block-118"><img
                    src="https://uploads-ssl.webflow.com/65129d80ea060cc3955c1aff/6512b6e931d22b6093e194b8_facebook-round-svgrepo-com%20(1).png"
                    loading="lazy" alt="" class="image-48" /><img
                    src="https://uploads-ssl.webflow.com/65129d80ea060cc3955c1aff/6512b6e9f41c615d871c8558_instagram-round-svgrepo-com%20(1).png"
                    loading="lazy" alt="" class="image-50" /><img
                    src="https://uploads-ssl.webflow.com/65129d80ea060cc3955c1aff/6512b6e970ad7f93986714eb_linkedin-round-svgrepo-com%201.png"
                    loading="lazy" alt="" /></div>
        </div>
    </div>
    <div>
        <div class="div-block-120"></div>
        <div class="div-block-117">
            <div class="text-block-72">POLITIQUE DE CONFIDENTIALITÉ</div>
            <div class="text-block-76">Mentions légales</div>
        </div>
    </div>

</section>
<?php else: ?>
<section class="section-7">
    <div class="div-block-96">
        <div class="div-block-97">
            <div class="div-block-102"><img
                    src="https://uploads-ssl.webflow.com/65130c8954d0600ce4133278/65130d1954d0600ce413b8fd_Previssime%20logo%20writed.png"
                    loading="lazy" width="90" alt="" class="image-42" /></div>
            <div class="text-block-55">© 2020 - Previssime</div>
        </div>
        <div class="div-block-98">
            <div class="text-block-56">Structure</div>
            <div class="text-block-57">Home</div>
            <div class="text-block-57">Tarif</div>
            <div class="text-block-57">Fonctionnalités</div>
            <div class="text-block-57">Contact</div>
        </div>
        <div class="div-block-105">
            <div class="text-block-56 m1">Contact</div>
            <div class="text-block-57 m1">info@previssime.ch</div>
            <div class="div-block-101"><img
                    src="https://uploads-ssl.webflow.com/65130c8954d0600ce4133278/651434cb06aa3104c4b2314b_facebook-round-svgrepo-com%20(1).png"
                    loading="lazy" alt="" class="image-44" /><img
                    src="https://uploads-ssl.webflow.com/65130c8954d0600ce4133278/651434cb06aa3104c4b2314f_instagram-round-svgrepo-com%20(1).png"
                    loading="lazy" alt="" class="image-45" /><img
                    src="https://uploads-ssl.webflow.com/65130c8954d0600ce4133278/651434cb06aa3104c4b2314d_linkedin-round-svgrepo-com%201.png"
                    loading="lazy" alt="" /></div>
        </div>
    </div>
    <div>
        <div class="div-block-103"></div>
        <div class="div-block-104">
            <div class="text-block-59">POLITIQUE DE CONFIDENTIALITÉ</div>
            <div class="text-block-60">Mentions légales</div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php /**PATH E:\24-10-2023\project\resources\views/layout/footer.blade.php ENDPATH**/ ?>