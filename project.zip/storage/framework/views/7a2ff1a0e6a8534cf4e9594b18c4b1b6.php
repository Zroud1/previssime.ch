<!DOCTYPE html >
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Fri Oct 06 2023 13:56:52 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-page="651c1bf7b7970eb87797b251">

<head>
   <?php echo $__env->make('layout.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->yieldContent('style'); ?>
</head>


   <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <?php echo $__env->yieldContent('content'); ?>


    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>



</html>
<?php /**PATH F:\24-10-2023\project\resources\views/layout/app.blade.php ENDPATH**/ ?>