

<?php /**PATH E:\26-10-2023\project\resources\views/layout/script.blade.php ENDPATH**/ ?>