<?php $__env->startSection('title'); ?> previssime landing page <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?>
<meta content="previssime landing page" property="og:title" />
<meta content="previssime landing page" property="twitter:title" />
<meta content="width=device-width, initial-scale=1" name="viewport" />
<meta content="Webflow" name="generator" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link href="<?php echo e(URL::asset('assets/first-page/css/style1.css')); ?>" rel="stylesheet" type="text/css" id="hrefLink" />
<style>

    #section-2,#section-3{
        display:none;
    }
    body{
        padding-top: 0;
      }


      @media (max-width: 767px) {
        .div-block-129 {
    min-height: 450px;
    align-items: center;
 }

  #displayNumeroAvsImage{
    margin-bottom: 8px;
  }
        .div-block-173 {
            flex-direction: column; /* Change flex direction to column for mobile */
        }

        .voirdoc{
        flex-direction: column;
        align-items: center;
        padding-right: 7px;padding-left: 7px;
        }

        .img-cin{
            display: flex;
    flex-direction: column;
        }
    }

    /* Media query for desktop devices */
    @media (min-width: 768px) {
        .div-block-173 {
            flex-direction: row; /* Change flex direction to row for desktop */
        }
        .input-first-form {
            width: 50%; /* Make each input take half of the width on desktop */
        }

    }


    @media only screen and (max-width: 767px) {
        .div-block-129 {
    min-height: 450px;
    align-items: center;




  }
  .img-cin{
            display: flex;
    flex-direction: column;
        }
        .div-block-128  canvas {
            height: 217px;; /* Adjust the height as needed for mobile layout */
    }


    }



    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(URL::asset('assets/first-page/script.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
      <form method="POST" action="<?php echo e(route('signaturepad')); ?>" enctype="multipart/form-data" >
        <?php echo csrf_field(); ?>
        <?php if(session('error')): ?>
            <div style="
            background-color: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
            padding: 12px;
            margin: 0 auto; /* This centers the alert horizontally */
            width: 50%; /* Adjust the width as needed */
            text-align: center; /* Center the text content */
            border: 1px solid transparent;
            border-radius: 4px;
            ">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php echo $__env->make('etaps-recuperer.first', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('etaps-recuperer.second', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('etaps-recuperer.third', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
  <script>



    document.addEventListener("DOMContentLoaded", function () {


        //   star SignaturePad

        var wrapper = document.getElementById("signature-pad");
        var canvas = wrapper.querySelector("canvas");

        var sign = new SignaturePad(document.getElementById('sign'), {
            backgroundColor: 'rgba(20, 11, 10, 0)',
            penColor: 'rgb(0, 0, 0)'
        });


        // Wrap your code in a setTimeout function
         function resizeCanvas() {

            var ratio =  Math.max(window.devicePixelRatio || 1, 1);

            canvas.width = canvas.offsetWidth * ratio;
            canvas.height = canvas.offsetHeight * ratio;
            canvas.getContext("2d").scale(ratio, ratio);
         }


        resizeCanvas();







        document.getElementById('clearBtn').addEventListener('click', function() {
            // Assuming 'sign' is the ID of the element you want to clear
            sign.clear();
            outputTextarea = document.getElementById('output');
            outputTextarea.value =  sign.toDataURL();

        });


        document.getElementById('next-btn2').addEventListener('click', function () {
            var dataURL = sign.toDataURL(); // Get base64 data URL
            var outputTextarea = document.getElementById('output');
            outputTextarea.value = dataURL;


        });

        //  end SignaturePad



        function displayStyle(currentSection) {
            var cssFileName = "assets/first-page/css/style" + currentSection + ".css";
            document.getElementById('hrefLink').href = cssFileName;

        }


        var currentSection = 1;
        function formatFieldName(fieldName) {
            var words = fieldName.split(/(?=[A-Z_])/);
            var formattedWords = words.map(function(word) {
                return word.replace(/_/g, ' ').toLowerCase();
            });
            var formattedField = formattedWords.map(function(word) {
                return word.charAt(0).toUpperCase() + word.slice(1);
            });
            return formattedField.join(' ');
        }
        function isValidEmail(email) {
            // A simple email validation regex
            var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }

        function isValidPassword(password) {
            // Password criteria: at least 8 characters, one letter, one number
            var passwordRegex = /^(?=.*[A-Za-z])(?=.*\d).{8,}$/;
            return passwordRegex.test(password);
        }

        function validateSection1() {
            var fields = [
                'nom', 'prenom', 'dateNaissance', 'adresse',
                'ville', 'pays', 'npa','telephone', 'numeroAvs',
                'caissePensionActuelle', 'travaille', 'salarie',
            ];

            for (var i = 0; i < fields.length; i++) {
                var fieldId = fields[i];
                var element = document.getElementById(fieldId);
                var errorSpan = document.getElementById(fieldId + 'Error'); // Get the error span element

                if (element) {
                    if (element.type === "radio" && !document.querySelector("input[name='" + element.name + "']:checked")) {
                        errorSpan.textContent = "Veuillez sélectionner une option pour " + formatFieldName(element.name);
                        return false;
                    }

                    if (element.value === "") {
                        errorSpan.textContent = "Veuillez remplir " + formatFieldName(element.name);
                        return false;
                    }

                    // Clear the error message if the field is valid
                    errorSpan.textContent = "";
                }

            }


            return true;
        }
        function getImageSizeInBytes(dataImage) {
            const base64Data = dataImage.split(',')[1];
            const decodedData = atob(base64Data);
            const sizeInBytes = decodedData.length;
            return sizeInBytes;
        }

        function validateSection2() {
            var fields = ['numeroAvsImage', 'caissePensionActuelleImage', 'output']; // Add 'output' to the fields array
             //3678
             for (var i = 0; i < fields.length; i++) {
                var fieldName = fields[i];
                var element = document.getElementById(fieldName);
                var errorSpan = document.getElementById(fieldName + 'Error'); // Get the error span element

                if (element) {
                    if (element.type === "file" && element.files.length === 0) {
                        errorSpan.textContent = "Veuillez sélectionner un fichier pour " + formatFieldName(fieldName);
                        return false;
                    }
                    if (element.type === "file" && element.files[0].size > 1024 * 1024) {
                        errorSpan.textContent = "La taille de l'image ne doit pas dépasser 1MB.";
                        return false;
                    }

                    // Check if the current element is the "output" element
                    if (fieldName === 'output') {
                        var outputValue = element.value;

                        var screenSize = window.innerWidth;
                        var maxSize;

                        if (screenSize >= 1200) {
                            maxSize = 16192;
                        } else if (screenSize >= 991 && screenSize <= 1199) {
                            maxSize = 8750;
                        } else if (screenSize <= 767) {
                            maxSize = 7928;
                        }
                         if ( sign.isEmpty()) {
                            errorSpan.textContent = "Signature vide. Veuillez signer avant de continuer.";
                            return false;
                        }
                    }


                    // Clear the error message if the field is valid
                    errorSpan.textContent = "";
                }
            }

            return true;
        }



        function validateSection3() {
            var fields = ['condition1', 'condition2', 'email', 'password', 'confirmerPassword'];
            var i, l = fields.length;
            var fieldId;

            // File input validation



            for (i = 0; i < l; i++) {
                fieldId = fields[i];
                var element = document.getElementById(fieldId);
                var errorElement = document.getElementById(fieldId + "Error");

                if (element) {
                    if (element.type === "checkbox" && !element.checked) {
                        errorElement.innerText = "Veuillez accepter le " + formatFieldName(element.name);
                        return false;
                    }

                    if (element.type === "password" && element.value.length < 8) {
                        errorElement.innerText = "Au moins 8 caractères requis.";
                        return false;
                    }

                    if (element.type === "password" && !/[a-zA-Z]/.test(element.value)) {
                        errorElement.innerText = "Au moins une lettre requise.";
                        return false;
                    }

                    if (element.type === "password" && !/\d/.test(element.value)) {
                        errorElement.innerText = "Au moins un chiffre requis.";
                        return false;
                    }

                    if (element.value === "") {
                        errorElement.innerText = "Veuillez remplir " + formatFieldName(element.name);
                        return false;
                    }

                    errorElement.innerText = ""; // Clear error message if valid
                }
            }

            // Check if password and confirmerPassword match
            var passwordElement = document.getElementById("password");
            var confirmerPasswordElement = document.getElementById("confirmerPassword");
            var confirmerPasswordError = document.getElementById("confirmerPasswordError");

            if (passwordElement.value !== confirmerPasswordElement.value) {
                confirmerPasswordError.innerText = "Les mots de passe ne correspondent pas.";
                return false;
            }

            return true;
        }





        // Define an array of validation functions for each section
        const validationFunctions = [validateSection1, validateSection2, validateSection3];
        // Combine and validate all sections
        function validateForm() {
            for (const validateSection of validationFunctions) {
                if (!validateSection()) {
                    return false; // Validation failed for at least one section
                }
            }
            return true; // All sections passed validation
        }
        // Attach the validation function to the form submission
        const form = document.querySelector('form');
        if (form) {
            form.onsubmit = function (event) {
                if (!validateForm()) {
                    event.preventDefault(); // Prevent form submission if validation fails
                }

            };
        }



        // Hide Sections 2 and 3 on page load

            displaySignaturePad=1
        document.querySelector("#next-btn").addEventListener("click", function () {
            if (currentSection = 1 && validateSection1()) {
                document.getElementById("section-" + 1).style.display = "none";
                ++currentSection;
                displayStyle(2)
                document.getElementById("section-" + 2).style.display = "flex";
                if(displaySignaturePad==1){
                    setTimeout(  resizeCanvas ,2 )
                    ++displaySignaturePad;
                }
            }
        });
        document.querySelector("#next-btn2").addEventListener("click", function () {
            if (currentSection = 2 && validateSection2()) {
                document.getElementById("section-" + 2).style.display = "none";

                displayStyle(3)
                document.getElementById("section-" + 3).style.display = "flex";
            }
        });

        document.querySelector("#prev-btn2").addEventListener("click", function () {
            if (currentSection = 2) {
                document.getElementById("section-" + currentSection).style.display = "none";
                --currentSection;
                displayStyle(1)
                document.getElementById("section-" + currentSection).style.display = "flex";
            }
        });
        document.querySelector("#prev-btn3").addEventListener("click", function () {
            if (currentSection = 3) {
                document.getElementById("section-" + currentSection).style.display = "none";
                --currentSection;
                displayStyle(2)
                document.getElementById("section-" + currentSection).style.display = "flex";
            }
        });

        document.getElementById('voir').addEventListener('click',function name(params) {
                 // Update the src attribute of 'displayNumeroAvsImage' with the selected image
                    var numeroAvsInput = document.getElementById('numeroAvsImage');
                        var displayNumeroAvsImage = document.getElementById('displayNumeroAvsImage');

                        numeroAvsInput.style.display = "inline-block";
                        displayNumeroAvsImage.style.display = "inline-block";

                    if (numeroAvsInput.files.length > 0) {
                        var selectedFile = numeroAvsInput.files[0];
                        displayNumeroAvsImage.src = URL.createObjectURL(selectedFile);
                    } else {
                        // Handle the case where no file is selected, e.g., set it to an empty image
                        displayNumeroAvsImage.src = '';
                    }

                    // Update the src attribute of 'displayCaissePensionActuelleImage' with the selected image
                    var caissePensionInput = document.getElementById('caissePensionActuelleImage');
                    var displayCaissePensionActuelleImage = document.getElementById('displayCaissePensionActuelleImage');

                    if (caissePensionInput.files.length > 0) {
                        var selectedFile = caissePensionInput.files[0];
                        displayCaissePensionActuelleImage.src = URL.createObjectURL(selectedFile);
                    } else {
                        // Handle the case where no file is selected, e.g., set it to an empty image
                        displayCaissePensionActuelleImage.src = '';
                    }
        })


    });



</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {


    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\02206\Desktop\project\resources\views/recuperer.blade.php ENDPATH**/ ?>