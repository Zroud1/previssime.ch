

<?php /**PATH F:\project\resources\views/layout/script.blade.php ENDPATH**/ ?>