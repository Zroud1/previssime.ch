<?php $__env->startSection('title'); ?> previssime landing page <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?>
<meta content="previssime landing page" property="og:title" />
<meta content="previssime landing page" property="twitter:title" />
<meta content="width=device-width, initial-scale=1" name="viewport" />
<meta content="Webflow" name="generator" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link href="<?php echo e(URL::asset('assets/landing-page/style.css')); ?>" rel="stylesheet" type="text/css" />
<style>

@media (max-width: 767px) {
    .middlebutton{
        width: 100%;display: flex; justify-content: center;z-index: 100;
    }
  }

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(URL::asset('assets/landing-page/script.js')); ?>"  type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<body class="body-2">


        <section class="section-9">
            <div class="div-block-134">
                <div class="text-block-86"><span class="text-span-9">Prévoyez l’avenir</span> en toute simplicité avec <span
                        class="text-span-10">Previssime</span></div>
                <div class="text-block-87">Chez <span class="text-span-11">Previssime</span>, nous croyons que votre
                    tranquilité d’esprit est notre <span class="text-span-12">priorité</span>.<br /><span
                        class="text-span-13">Previssime</span> se charge de rechercher vos avoirs de 2ème pilier auprès de
                    <span class="text-span-14">1500 instituts</span> de prévoyance <span class="text-span-15">Suisse</span>
                </div>
                <br><br><br>
                <div class="middlebutton">          <a href="<?php echo e(url('/recuperer')); ?>" class="button-8 w-button">Récupérer vos avoirs</a></div>
            </div>
            <div class="div-block-135"><img
                    src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c2a177db4f38d104e1275_illustration%20landing%20page%202%202.png"
                    loading="lazy" width="480" sizes="(max-width: 767px) 100vw, (max-width: 991px) 650px, 47vw" alt=""
                    srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c2a177db4f38d104e1275_illustration%20landing%20page%202%202-p-500.png 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c2a177db4f38d104e1275_illustration%20landing%20page%202%202-p-800.png 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c2a177db4f38d104e1275_illustration%20landing%20page%202%202-p-1080.png 1080w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c2a177db4f38d104e1275_illustration%20landing%20page%202%202-p-1600.png 1600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c2a177db4f38d104e1275_illustration%20landing%20page%202%202.png 2000w"
                    class="image-53" /></div>
        </section>
        <section class="section-10">
            <div class="div-block-165">
                <div class="div-block-164">
                    <div class="text-block-88">Le système de prévoyance suisse</div>
                    <div class="text-block-89">Le système de prévoyance et de retraite suisse des 3 piliers permet de
                        préparer votre retraite, de vous protéger des coups durs ainsi que votre famille en cas d’invalidité
                        ou de décès mais aussi faire baisser vos impôts à travers un placement.</div>
                </div>
            </div>
            <div data-w-id="54dbea04-7a4f-534f-4d3a-22ed8ecda11b"
                style="-webkit-transform:translate3d(0vw, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0vw, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0vw, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0vw, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0)"
                class="sliders-father">
                <div class="the-sliders"><a href="#" class="w-inline-block">
                        <div class="columns-slid"><img
                                src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e304cd28c3e4342af17_recuperer%20mes%20avoirs.jpg"
                                loading="lazy" sizes="(max-width: 991px) 100vw, 17vw"
                                srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e304cd28c3e4342af17_recuperer%20mes%20avoirs-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e304cd28c3e4342af17_recuperer%20mes%20avoirs-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e304cd28c3e4342af17_recuperer%20mes%20avoirs.jpg 1000w"
                                alt="" class="image-54" />
                            <div class="div-block-139">
                                <div class="poppins-medium-20-26">RECHERCHER<br />VOS AVOIRS LPP</div>
                            </div>
                        </div>
                    </a><a href="#" class="w-inline-block">
                        <div class="columns-slid"><img
                                src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e3065c348d7c5a6e2c9_retraite.jpg"
                                loading="lazy" sizes="(max-width: 991px) 100vw, 17vw"
                                srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e3065c348d7c5a6e2c9_retraite-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e3065c348d7c5a6e2c9_retraite-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e3065c348d7c5a6e2c9_retraite.jpg 1000w"
                                alt="" class="image-54" />
                            <div class="div-block-139">
                                <div class="poppins-medium-20-26">PRÉPARER VOTRE RETRAITE</div>
                            </div>
                        </div>
                    </a><a href="#" class="w-inline-block">
                        <div class="columns-slid"><img
                                src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e6a284b0413bffb9d0e_famille.jpg"
                                loading="lazy" sizes="(max-width: 991px) 100vw, 17vw"
                                srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e6a284b0413bffb9d0e_famille-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e6a284b0413bffb9d0e_famille-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e6a284b0413bffb9d0e_famille.jpg 1000w"
                                alt="" class="image-54" />
                            <div class="div-block-139">
                                <div class="poppins-medium-20-26">PROTEGER VOTRE FAMILLE</div>
                            </div>
                        </div>
                    </a><a href="#" class="w-inline-block">
                        <div class="columns-slid"><img
                                src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery.jpg"
                                loading="lazy" sizes="(max-width: 991px) 100vw, 17vw"
                                srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery.jpg 1000w"
                                alt="" class="image-54" />
                            <div class="div-block-139">
                                <div class="poppins-medium-20-26">COMMENT DEVENIR PROPRIÉTAIRE</div>
                            </div>
                        </div>
                    </a><a href="#" class="w-inline-block">
                        <div class="columns-slid margin"><img
                                src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e305190e82a7e56de19_signatures.jpg"
                                loading="lazy" sizes="(max-width: 991px) 100vw, 17vw"
                                srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e305190e82a7e56de19_signatures-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e305190e82a7e56de19_signatures-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e305190e82a7e56de19_signatures.jpg 1000w"
                                alt="" class="image-54" />
                            <div class="div-block-139">
                                <div class="poppins-medium-20-26">CONSEIL GLOBAL</div>
                            </div>
                        </div>
                    </a></div>
                <div class="the-sliders"><a href="#" class="w-inline-block">
                        <div class="columns-slid"><img
                                src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e304cd28c3e4342af17_recuperer%20mes%20avoirs.jpg"
                                loading="lazy" sizes="(max-width: 991px) 100vw, 17vw"
                                srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e304cd28c3e4342af17_recuperer%20mes%20avoirs-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e304cd28c3e4342af17_recuperer%20mes%20avoirs-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e304cd28c3e4342af17_recuperer%20mes%20avoirs.jpg 1000w"
                                alt="" class="image-54" />
                            <div class="div-block-139">
                                <div class="poppins-medium-20-26">RECHERCHER<br />VOS AVOIRS LPP</div>
                            </div>
                        </div>
                    </a><a href="#" class="w-inline-block">
                        <div class="columns-slid"><img
                                src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e3065c348d7c5a6e2c9_retraite.jpg"
                                loading="lazy" sizes="(max-width: 991px) 100vw, 17vw"
                                srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e3065c348d7c5a6e2c9_retraite-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e3065c348d7c5a6e2c9_retraite-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e3065c348d7c5a6e2c9_retraite.jpg 1000w"
                                alt="" class="image-54" />
                            <div class="div-block-139">
                                <div class="poppins-medium-20-26">PRÉPARER VOTRE RETRAITE</div>
                            </div>
                        </div>
                    </a><a href="#" class="w-inline-block">
                        <div class="columns-slid"><img
                                src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e6a284b0413bffb9d0e_famille.jpg"
                                loading="lazy" sizes="(max-width: 991px) 100vw, 17vw"
                                srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e6a284b0413bffb9d0e_famille-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e6a284b0413bffb9d0e_famille-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e6a284b0413bffb9d0e_famille.jpg 1000w"
                                alt="" class="image-54" />
                            <div class="div-block-139">
                                <div class="poppins-medium-20-26">PROTEGER VOTRE FAMILLE</div>
                            </div>
                        </div>
                    </a><a href="#" class="w-inline-block">
                        <div class="columns-slid"><img
                                src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery.jpg"
                                loading="lazy" sizes="(max-width: 991px) 100vw, 17vw"
                                srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery.jpg 1000w"
                                alt="" class="image-54" />
                            <div class="div-block-139">
                                <div class="poppins-medium-20-26">COMMENT DEVENIR PROPRIÉTAIRE</div>
                            </div>
                        </div>
                    </a><a href="#" class="w-inline-block">
                        <div class="columns-slid margin"><img
                                src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e305190e82a7e56de19_signatures.jpg"
                                loading="lazy" sizes="(max-width: 991px) 100vw, 17vw"
                                srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e305190e82a7e56de19_signatures-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e305190e82a7e56de19_signatures-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65362e305190e82a7e56de19_signatures.jpg 1000w"
                                alt="" class="image-54" />
                            <div class="div-block-139">
                                <div class="poppins-medium-20-26">CONSEIL GLOBAL</div>
                            </div>
                        </div>
                    </a></div>
            </div>
            <div data-w-id="79b270d6-684b-3003-5535-8fd5e3700de4" class="sliter-father-mob">
                <div class="slider-mob">
                    <div class="columns-slid"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash.jpg"
                            loading="lazy"
                            sizes="(max-width: 479px) 100vw, (max-width: 767px) 34vw, (max-width: 991px) 250px, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-1080.jpg 1080w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-1600.jpg 1600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-2000.jpg 2000w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-2600.jpg 2600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-3200.jpg 3200w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash.jpg 3376w"
                            alt="" class="image-54" />
                        <div class="div-block-139">
                            <div class="poppins-medium-20-26">RECHERCHER<br />VOS AVOIRS LPP</div>
                        </div>
                    </div>
                    <div class="columns-slid"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo.jpg"
                            loading="lazy"
                            sizes="(max-width: 479px) 100vw, (max-width: 767px) 34vw, (max-width: 991px) 250px, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo.jpg 1000w"
                            alt="" class="image-54" />
                        <div class="div-block-139">
                            <div class="poppins-medium-20-26">PRÉPARER VOTRE RETRAITE</div>
                        </div>
                    </div>
                    <div class="columns-slid"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael.jpg"
                            loading="lazy"
                            sizes="(max-width: 479px) 100vw, (max-width: 767px) 34vw, (max-width: 991px) 250px, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael.jpg 1000w"
                            alt="" class="image-54" />
                        <div class="div-block-139">
                            <div class="poppins-medium-20-26">PROTEGER VOTRE FAMILLE</div>
                        </div>
                    </div>
                    <div class="columns-slid"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery.jpg"
                            loading="lazy"
                            sizes="(max-width: 479px) 100vw, (max-width: 767px) 34vw, (max-width: 991px) 250px, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery.jpg 1000w"
                            alt="" class="image-54" />
                        <div class="div-block-139">
                            <div class="poppins-medium-20-26">COMMENT DEVENIR PROPRIÉTAIRE</div>
                        </div>
                    </div>
                    <div class="columns-slid"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa.jpg"
                            loading="lazy"
                            sizes="(max-width: 479px) 100vw, (max-width: 767px) 34vw, (max-width: 991px) 250px, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa.jpg 1000w"
                            alt="" class="image-54" />
                        <div class="div-block-139">
                            <div class="poppins-medium-20-26">CONSEIL GLOBAL</div>
                        </div>
                    </div>
                </div>
                <div class="slider-mob">
                    <div class="columns-slid"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash.jpg"
                            loading="lazy"
                            sizes="(max-width: 479px) 100vw, (max-width: 767px) 34vw, (max-width: 991px) 250px, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-1080.jpg 1080w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-1600.jpg 1600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-2000.jpg 2000w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-2600.jpg 2600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-3200.jpg 3200w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash.jpg 3376w"
                            alt="" class="image-54" />
                        <div class="div-block-139">
                            <div class="poppins-medium-20-26">RECHERCHER<br />VOS AVOIRS LPP</div>
                        </div>
                    </div>
                    <div class="columns-slid"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo.jpg"
                            loading="lazy"
                            sizes="(max-width: 479px) 100vw, (max-width: 767px) 34vw, (max-width: 991px) 250px, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo.jpg 1000w"
                            alt="" class="image-54" />
                        <div class="div-block-139">
                            <div class="poppins-medium-20-26">PRÉPARER VOTRE RETRAITE</div>
                        </div>
                    </div>
                    <div class="columns-slid"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael.jpg"
                            loading="lazy"
                            sizes="(max-width: 479px) 100vw, (max-width: 767px) 34vw, (max-width: 991px) 250px, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael.jpg 1000w"
                            alt="" class="image-54" />
                        <div class="div-block-139">
                            <div class="poppins-medium-20-26">PROTEGER VOTRE FAMILLE</div>
                        </div>
                    </div>
                    <div class="columns-slid"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery.jpg"
                            loading="lazy"
                            sizes="(max-width: 479px) 100vw, (max-width: 767px) 34vw, (max-width: 991px) 250px, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery.jpg 1000w"
                            alt="" class="image-54" />
                        <div class="div-block-139">
                            <div class="poppins-medium-20-26">COMMENT DEVENIR PROPRIÉTAIRE</div>
                        </div>
                    </div>
                    <div class="columns-slid"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa.jpg"
                            loading="lazy"
                            sizes="(max-width: 479px) 100vw, (max-width: 767px) 34vw, (max-width: 991px) 250px, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa.jpg 1000w"
                            alt="" class="image-54" />
                        <div class="div-block-139">
                            <div class="poppins-medium-20-26">CONSEIL GLOBAL</div>
                        </div>
                    </div>
                </div>
            </div>
            <div data-w-id="617c4c08-6158-b72a-ef51-759e080a7d14"
                style="-webkit-transform:translate3d(0vw, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0vw, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0vw, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0vw, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0)"
                class="slider-father-mob-small">
                <div class="slide-mob-small">
                    <div class="div-block-166"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash.jpg"
                            loading="lazy" sizes="(max-width: 479px) 38vw, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-1080.jpg 1080w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-1600.jpg 1600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-2000.jpg 2000w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-2600.jpg 2600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-3200.jpg 3200w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash.jpg 3376w"
                            alt="" class="image-59" />
                        <div class="div-block-167">
                            <div class="text-block-105">RECHERCHER VOS AVOIRS LPP</div>
                        </div>
                    </div>
                    <div class="div-block-166"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo.jpg"
                            loading="lazy" sizes="(max-width: 479px) 38vw, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo.jpg 1000w"
                            alt="" class="image-59" />
                        <div class="div-block-167">
                            <div class="text-block-105">PRÉPARER VOTRE RETRAITE</div>
                        </div>
                    </div>
                    <div class="div-block-166"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael.jpg"
                            loading="lazy" sizes="(max-width: 479px) 38vw, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael.jpg 1000w"
                            alt="" class="image-59" />
                        <div class="div-block-167">
                            <div class="text-block-105">PROTEGER VOTRE FAMILLE</div>
                        </div>
                    </div>
                    <div class="div-block-166"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery.jpg"
                            loading="lazy" sizes="(max-width: 479px) 38vw, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery.jpg 1000w"
                            alt="" class="image-59" />
                        <div class="div-block-167">
                            <div class="text-block-105">COMMENT DEVENIR PROPRIÉTAIRE</div>
                        </div>
                    </div>
                    <div class="div-block-166"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa.jpg"
                            loading="lazy" sizes="(max-width: 479px) 38vw, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa.jpg 1000w"
                            alt="" class="image-59" />
                        <div class="div-block-167">
                            <div class="text-block-105">CONSEIL GLOBAL<br /></div>
                        </div>
                    </div>
                </div>
                <div class="slide-mob-small">
                    <div class="div-block-166"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash.jpg"
                            loading="lazy" sizes="(max-width: 479px) 38vw, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-1080.jpg 1080w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-1600.jpg 1600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-2000.jpg 2000w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-2600.jpg 2600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash-p-3200.jpg 3200w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27c6e08c1f466a00b8_rayul-_M6gy9oHgII-unsplash.jpg 3376w"
                            alt="" class="image-59" />
                        <div class="div-block-167">
                            <div class="text-block-105">RECHERCHER VOS AVOIRS LPP</div>
                        </div>
                    </div>
                    <div class="div-block-166"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo.jpg"
                            loading="lazy" sizes="(max-width: 479px) 38vw, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1b166069bbc270ab6e_ayo.jpg 1000w"
                            alt="" class="image-59" />
                        <div class="div-block-167">
                            <div class="text-block-105">PRÉPARER VOTRE RETRAITE</div>
                        </div>
                    </div>
                    <div class="div-block-166"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael.jpg"
                            loading="lazy" sizes="(max-width: 479px) 38vw, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bfc61e97420f0fd14_michael.jpg 1000w"
                            alt="" class="image-59" />
                        <div class="div-block-167">
                            <div class="text-block-105">PROTEGER VOTRE FAMILLE</div>
                        </div>
                    </div>
                    <div class="div-block-166"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery.jpg"
                            loading="lazy" sizes="(max-width: 479px) 38vw, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bae7488af9d140897_jeffery.jpg 1000w"
                            alt="" class="image-59" />
                        <div class="div-block-167">
                            <div class="text-block-105">COMMENT DEVENIR PROPRIÉTAIRE</div>
                        </div>
                    </div>
                    <div class="div-block-166"><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa.jpg"
                            loading="lazy" sizes="(max-width: 479px) 38vw, 100vw"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa.jpg 1000w"
                            alt="" class="image-59" />
                        <div class="div-block-167">
                            <div class="text-block-105">CONSEIL GLOBAL<br /></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="section-11">
            <div class="div-block-140">
                <div class="div-block-142"><img
                        src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c358ff4ae9f57c52b01f0_Previssime%20only%20the%20logo%206.png"
                        loading="lazy" width="100" alt="" />
                    <div class="div-block-141">
                        <div class="text-block-91">ourquoi<span class="text-span-16">?</span></div>
                        <div class="text-block-92">revissime</div>
                    </div>
                </div>
                <div class="div-block-143">
                    <div class="text-block-93">“</div>
                </div>
            </div>
            <div class="div-block-144">
                <div class="div-block-145">
                    <div class="text-block-94">Chez Previssime, nous comprenons que la gestion du 2ème pilier et le choix du
                        3ème pilier peuvent être déroutants. C&#x27;est pourquoi notre équipe d&#x27;experts indépendants
                        travaille en collaboration avec les meilleurs partenaires pour vous offrir une solution de
                        préparation à la retraite sécurisée et optimale. Avec Previssime, votre avenir financier est entre
                        de bonnes mains.</div>
                </div>
                <div class="div-block-146">
                    <div class="div-block-147">
                        <div class="text-block-95">Retrouvez <span class="text-span-20">vos avoirs</span> de <span
                                class="text-span-17">2ème</span> pilier</div>
                        <div class="text-block-96">Plus de <span class="text-span-18">13 Milliards</span> de Francs suisse
                            égarés, avec un rendement quasi nul de <span class="text-span-19">0,01%</span> auprès de la
                            fondation supplétive. Remplissez le formulaire de recherche et <span
                                class="text-span-21">Previssime</span> s’occupe des démarches administratives pour retrouver
                            vos avoirs égarés afin de les regrouper et les sécuriser.</div>
                        <div class="text-block-96 weight">Retrouvez vos avoirs en libre passage ne prend que quelques
                            minutes.</div>
                        <div class="div-block-148">
                            <div class="div-block-149"><img
                                    src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c4138f412556e62f1dc9a_app-store-svgrepo-com%201.png"
                                    loading="lazy" alt="" class="image-56" />
                                <div>
                                    <div class="text-block-97">App Store</div>
                                    <div class="text-block-98">TÉLÉCHARGER SUR APP STORE</div>
                                </div>
                            </div>
                            <div class="div-block-149 width margin"><img
                                    src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c41384afbac7692f32326_google-play-svgrepo-com%201.png"
                                    loading="lazy" alt="" class="image-56" />
                                <div>
                                    <div class="text-block-97">Google Play</div>
                                    <div class="text-block-98">TÉLÉCHARGER SUR GOOGLE PLAY</div>
                                </div>
                            </div>
                        </div>
                        <div class="text-block-117">Bientot Disponible.</div>
                    </div>
                    <div><img
                            src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c40faf49e9bf4a8527af8_mockup%20telephone.png"
                            loading="lazy" sizes="(max-width: 479px) 90vw, 298.84375px"
                            srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c40faf49e9bf4a8527af8_mockup%20telephone-p-500.png 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c40faf49e9bf4a8527af8_mockup%20telephone-p-800.png 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c40faf49e9bf4a8527af8_mockup%20telephone-p-1080.png 1080w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c40faf49e9bf4a8527af8_mockup%20telephone.png 1480w"
                            alt="" class="image-55" /></div>
                    <div class="div-block-168">
                        <div class="div-block-149"><img
                                src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c4138f412556e62f1dc9a_app-store-svgrepo-com%201.png"
                                loading="lazy" alt="" class="image-56" />
                            <div>
                                <div class="text-block-97">App Store</div>
                                <div class="text-block-98">TÉLÉCHARGER SUR APP STORE</div>
                            </div>
                        </div>
                        <div class="div-block-149 width margin"><img
                                src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c41384afbac7692f32326_google-play-svgrepo-com%201.png"
                                loading="lazy" alt="" class="image-56" />
                            <div>
                                <div class="text-block-97">Google Play</div>
                                <div class="text-block-98">TÉLÉCHARGER SUR GOOGLE PLAY</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="testimonial-slider-large">
            <div class="text-block-118">Questions fréquentes </div>
            <div class="container-3">
                <div data-delay="4000" data-animation="slide" class="testimonial-slider-two w-slider" data-autoplay="false"
                    data-easing="ease" data-hide-arrows="false" data-disable-swipe="false" data-autoplay-limit="0"
                    data-nav-spacing="12" data-duration="500" data-infinite="true">
                    <div class="w-slider-mask">
                        <div class="w-slide">
                            <div class="testimonial-slide">
                                <div class="testimonial-content">
                                    <div class="text-block-106">Dans quels cas arrive-t-il que nous ayons un avoir égaré ?
                                    </div>
                                    <div class="testimonial-quote">A chaque fois qu&#x27;il y a cessation ou changement de
                                        l&#x27;activité professionnelle, voici les cas les plus fréquents :<br />‍<br />-
                                        Changement d&#x27;employeur<br />- Chomage<br />- Congé sabbatique <br />- Éducation
                                        des enfants<br />- Divorce<br />- Départ définitif de la Suisse</div>
                                </div><img
                                    src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65363c23fbedbc07cc90306f_question%20frequentes%201.png"
                                    loading="lazy"
                                    sizes="(max-width: 479px) 100vw, (max-width: 767px) 89vw, (max-width: 991px) 23vw, 24vw"
                                    srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65363c23fbedbc07cc90306f_question%20frequentes%201-p-500.png 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65363c23fbedbc07cc90306f_question%20frequentes%201-p-800.png 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65363c23fbedbc07cc90306f_question%20frequentes%201-p-1080.png 1080w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65363c23fbedbc07cc90306f_question%20frequentes%201-p-1600.png 1600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65363c23fbedbc07cc90306f_question%20frequentes%201-p-2000.png 2000w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65363c23fbedbc07cc90306f_question%20frequentes%201-p-2600.png 2600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65363c23fbedbc07cc90306f_question%20frequentes%201-p-3200.png 3200w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65363c23fbedbc07cc90306f_question%20frequentes%201.png 4167w"
                                    alt="" class="testimonial-image-two" />
                            </div>
                        </div>
                        <div class="w-slide">
                            <div class="testimonial-slide">
                                <div class="testimonial-content">
                                    <div class="h1-question">Dans quel cas est-il intéressant de faire une recherche ?</div>
                                    <div class="testimonial-quote">Vous n’êtes pas certain de toujours avoir transféré vos
                                        avoirs lors de vos changements/cessations d’activités<br />Vous recherchez des fonds
                                        propres pour votre futur logement<br />Vous recherchez des fonds propres pour vous
                                        mettre à votre compte<br />Vous souhaitez planifier votre retraiteVous souhaitez
                                        planifier votre succession<br />Un de vos proches est décédé et souhaitez savoir
                                        s’il avait des avoirs méconnus.<br />Vous êtes juste curieux</div>
                                </div><img
                                    src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65364d5627cc06638de4fc56_question%20frequentes.png"
                                    loading="lazy"
                                    sizes="(max-width: 479px) 100vw, (max-width: 767px) 89vw, (max-width: 991px) 23vw, 24vw"
                                    srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65364d5627cc06638de4fc56_question%20frequentes-p-500.png 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65364d5627cc06638de4fc56_question%20frequentes-p-800.png 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65364d5627cc06638de4fc56_question%20frequentes-p-1080.png 1080w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65364d5627cc06638de4fc56_question%20frequentes-p-1600.png 1600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65364d5627cc06638de4fc56_question%20frequentes-p-2000.png 2000w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65364d5627cc06638de4fc56_question%20frequentes-p-2600.png 2600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65364d5627cc06638de4fc56_question%20frequentes-p-3200.png 3200w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/65364d5627cc06638de4fc56_question%20frequentes.png 3334w"
                                    alt="" class="testimonial-image-two" />
                            </div>
                        </div>
                        <div class="w-slide">
                            <div class="testimonial-slide question-3">
                                <div class="testimonial-content">
                                    <div class="h1-question">Qu’est-ce que la Centrale du 2ème pilier ?</div>
                                    <div class="testimonial-quote size">La Centrale du 2ème pilier est l’organe de liaison
                                        entre les institutions de la prévoyance professionnelle (appelée aussi 2ème pilier
                                        ou LPP) et les assurés. Elle a pour but d’arriver à rétablir les contacts rompus
                                        entre les assurés et les institutions. Elle ne gère aucun compte d’assuré ni aucun
                                        avoir. C’est un service financé par la Confédération et ses recherches sont
                                        gratuites pour le requérant.</div>
                                </div>
                            </div>
                        </div>
                        <div class="w-slide">
                            <div class="testimonial-slide question-4">
                                <div class="testimonial-content">
                                    <div class="h1-question">Dois-je intervenir à un moment du processus ?</div>
                                    <div class="testimonial-quote size">Une fois que vous aurez validé votre demande de
                                        recherche, vous ne devrez plus rien faire, si ce n’est être patient ! Vous recevrez
                                        un courrier lorsque nous aurons reçu les résultats.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-slider-arrow w-slider-arrow-left">
                        <div class="w-icon-slider-left"></div>
                    </div>
                    <div class="testimonial-slider-arrow w-slider-arrow-right">
                        <div class="w-icon-slider-right"></div>
                    </div>
                    <div class="testimonial-slider-nav w-slider-nav w-slider-nav-invert w-round"></div>
                </div>
            </div>
            <div class="div-block-187">
                <div class="div-block-188"></div>
                <div class="div-block-189"></div>
            </div>
        </section>
        <section>
            <div class="div-block-25">
                <div class="text-block-24">Questions fréquentes</div>
                <div class="div-block-24">
                    <div class="div-block-23">
                        <div class="div-block-22">
                            <div class="text-block-25">1- Lorem ipsum dolor sit amet, consectetur adipiscing elit ?</div>
                            <div class="text-block-26">+</div>
                        </div>
                        <div class="div-block-21"></div>
                        <div class="text-block-27">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua.</div>
                    </div>
                    <div class="div-block-23">
                        <div class="div-block-22">
                            <div class="text-block-25">2- Lorem ipsum dolor sit amet, consectetur adipiscing elit ?</div>
                            <div class="text-block-26">+</div>
                        </div>
                        <div class="div-block-21"></div>
                        <div class="text-block-27">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua.</div>
                    </div>
                    <div class="div-block-23">
                        <div class="div-block-22">
                            <div class="text-block-25">3- Lorem ipsum dolor sit amet, consectetur adipiscing elit ?</div>
                            <div class="text-block-26">+</div>
                        </div>
                        <div class="div-block-21"></div>
                        <div class="text-block-27">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. </div>
                    </div>
                    <div class="div-block-23">
                        <div class="div-block-22">
                            <div class="text-block-25">4- Lorem ipsum dolor sit amet, consectetur adipiscing elit ?</div>
                            <div class="text-block-26">+</div>
                        </div>
                        <div class="div-block-21"></div>
                        <div class="text-block-27">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua.</div>
                    </div>
                    <div class="div-block-23">
                        <div class="div-block-22">
                            <div class="text-block-25">5- Lorem ipsum dolor sit amet, consectetur adipiscing elit ?</div>
                            <div class="text-block-26">+</div>
                        </div>
                        <div class="div-block-21"></div>
                        <div class="text-block-27">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="testimonial-slider-small">
            <div class="container-4">
                <h2 class="centered-heading">Avis Clients</h2>
                <p class="centered-subheading">Des dizaines de milliers d’utilisateurs ont retrouvé des avoirs égarés et
                    sont satisfaits des solutions que nous leur avons proposées.</p>
                <div data-delay="4000" data-animation="slide" class="testimonial-slider w-slider" data-autoplay="false"
                    data-easing="ease" data-hide-arrows="true" data-disable-swipe="false" data-autoplay-limit="0"
                    data-nav-spacing="3" data-duration="500" data-infinite="true">
                    <div class="w-slider-mask">
                        <div class="testimonial-slide-wrapper w-slide">
                            <div class="testimonial-card">
                                <p>Je suis soulagée de savoir que toutes mes cotisations sont désormais regroupées au même
                                    endroit (ce qui n&#x27;était pas le cas auparavant)... Sans votre aide, je n&#x27;aurais
                                    sans doute jamais pris les mesures nécessaires.</p>
                                <div class="testimonial-info"><img
                                        src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651d21224336f03440b9d5e1_joseph%201x1.jpg"
                                        loading="lazy" sizes="(max-width: 479px) 100vw, 60px"
                                        srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651d21224336f03440b9d5e1_joseph%201x1-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651d21224336f03440b9d5e1_joseph%201x1-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651d21224336f03440b9d5e1_joseph%201x1.jpg 1000w"
                                        alt="" class="testimonial-image-2" />
                                    <div>
                                        <h3 class="testimonial-author">Joseph G.</h3>
                                        <div class="tagline">a fait une demande le 09 Juin</div>
                                    </div>
                                    <div class="testimonial-icon-wrapper"><img
                                            src="https://assets-global.website-files.com/62434fa732124a0fb112aab4/62434fa732124a6c9412aae6_double-quotes-l.svg"
                                            loading="lazy" alt="" class="image-60" /></div>
                                </div>
                            </div>
                        </div>
                        <div class="testimonial-slide-wrapper w-slide">
                            <div class="testimonial-card">
                                <p>Efficacité, rapidité, simplicité et sécurité. Sans oublier des personnes très agréables.
                                    Merci beaucoup.</p>
                                <div class="testimonial-info"><img
                                        src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a26d1289309be5acf5c_jack-finnigan-rriAI0nhcbc-unsplash.jpg"
                                        loading="lazy" sizes="(max-width: 479px) 100vw, 60px"
                                        srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a26d1289309be5acf5c_jack-finnigan-rriAI0nhcbc-unsplash-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a26d1289309be5acf5c_jack-finnigan-rriAI0nhcbc-unsplash-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a26d1289309be5acf5c_jack-finnigan-rriAI0nhcbc-unsplash-p-1080.jpg 1080w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a26d1289309be5acf5c_jack-finnigan-rriAI0nhcbc-unsplash-p-1600.jpg 1600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a26d1289309be5acf5c_jack-finnigan-rriAI0nhcbc-unsplash-p-2000.jpg 2000w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a26d1289309be5acf5c_jack-finnigan-rriAI0nhcbc-unsplash.jpg 2363w"
                                        alt="" class="testimonial-image-2" />
                                    <div>
                                        <h3 class="testimonial-author">Jack F.</h3>
                                        <div class="tagline">a fait une demande le 02 Octobre</div>
                                    </div>
                                    <div class="testimonial-icon-wrapper"><img
                                            src="https://assets-global.website-files.com/62434fa732124a0fb112aab4/62434fa732124a6c9412aae6_double-quotes-l.svg"
                                            loading="lazy" alt="" class="image-60" /></div>
                                </div>
                            </div>
                        </div>
                        <div class="testimonial-slide-wrapper w-slide">
                            <div class="testimonial-card">
                                <p class="paragraph">Un courrier m&#x27;a été envoyé contenant des avoirs LPP dans plusieurs
                                    endroits, suivi d&#x27;un appel téléphonique très clair pour m&#x27;aider à regrouper
                                    mes fonds.</p>
                                <div class="testimonial-info"><img
                                        src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27b7da49297dd44b64_joseph-gonzalez-iFgRcqHznqg-unsplash.jpg"
                                        loading="lazy" sizes="(max-width: 479px) 100vw, 60px"
                                        srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27b7da49297dd44b64_joseph-gonzalez-iFgRcqHznqg-unsplash-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27b7da49297dd44b64_joseph-gonzalez-iFgRcqHznqg-unsplash-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27b7da49297dd44b64_joseph-gonzalez-iFgRcqHznqg-unsplash-p-1080.jpg 1080w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27b7da49297dd44b64_joseph-gonzalez-iFgRcqHznqg-unsplash-p-1600.jpg 1600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27b7da49297dd44b64_joseph-gonzalez-iFgRcqHznqg-unsplash-p-2000.jpg 2000w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27b7da49297dd44b64_joseph-gonzalez-iFgRcqHznqg-unsplash-p-2600.jpg 2600w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27b7da49297dd44b64_joseph-gonzalez-iFgRcqHznqg-unsplash-p-3200.jpg 3200w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5a27b7da49297dd44b64_joseph-gonzalez-iFgRcqHznqg-unsplash.jpg 3569w"
                                        alt="" class="testimonial-image-2" />
                                    <div>
                                        <h3 class="testimonial-author">Ian D.</h3>
                                        <div class="tagline">a fait une demande le 2 novembre</div>
                                    </div>
                                    <div class="testimonial-icon-wrapper"><img
                                            src="https://assets-global.website-files.com/62434fa732124a0fb112aab4/62434fa732124a6c9412aae6_double-quotes-l.svg"
                                            loading="lazy" alt="" /></div>
                                </div>
                            </div>
                        </div>
                        <div class="testimonial-slide-wrapper w-slide">
                            <div class="testimonial-card">
                                <p class="paragraph-2">Un processus compliqué qui est désormais très simple
                                    d&#x27;utilisation ! Merci à vous tous !!</p>
                                <div class="testimonial-info"><img
                                        src="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa.jpg"
                                        loading="lazy" sizes="(max-width: 479px) 100vw, 60px"
                                        srcset="https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa-p-500.jpg 500w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa-p-800.jpg 800w, https://assets-global.website-files.com/65129d80ea060cc3955c1aff/651c5c1bd9df8d7d1a4f621c_toa.jpg 1000w"
                                        alt="" class="testimonial-image-2" />
                                    <div>
                                        <h3 class="testimonial-author">Ema T.</h3>
                                        <div class="tagline">a fait une demande le 09 Mars</div>
                                    </div>
                                    <div class="testimonial-icon-wrapper"><img
                                            src="https://assets-global.website-files.com/62434fa732124a0fb112aab4/62434fa732124a6c9412aae6_double-quotes-l.svg"
                                            loading="lazy" alt="" /></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-slider-left w-slider-arrow-left">
                        <div class="arrow-wrapper"><img
                                src="https://assets-global.website-files.com/62434fa732124a0fb112aab4/62434fa732124a0e4912aadb_Chevron%20right-1.svg"
                                loading="lazy" alt="" class="slider-arrow-embed" /></div>
                    </div>
                    <div class="testimonial-slider-right w-slider-arrow-right">
                        <div class="arrow-wrapper"><img
                                src="https://assets-global.website-files.com/62434fa732124a0fb112aab4/62434fa732124a7ce212aacc_Chevron%20right.svg"
                                loading="lazy" alt="" class="slider-arrow-embed" /></div>
                    </div>
                    <div class="testimonial-slide-nav w-slider-nav w-round"></div>
                </div>
            </div>
            <h1 class="heading">Vous pouvez aussi nous laisser un commentaire</h1>
            <div class="w-form">
                <form id="email-form" name="email-form" data-name="Email Form" method="get" class="form-3"
                    data-wf-page-id="651c1bf7b7970eb87797b251" data-wf-element-id="0e92d0c2-ec82-a9a4-d776-5ce6456e3c34">
                    <label for="name" class="field-label-5">Nom </label><input type="text" class="text-field-4 w-input"
                        maxlength="256" name="name" data-name="Name" placeholder="" id="name" /><label for="email"
                        class="field-label-4">Adresse E-mail</label><input type="email" class="text-field-5 w-input"
                        maxlength="256" name="email" data-name="Email" placeholder="" id="email" required="" /><label
                        for="email-2" class="field-label-4">Commentaire</label><input type="text"
                        class="commentaire w-input" maxlength="256" name="email-2" data-name="Email 2" placeholder=""
                        id="email-2" required="" /><input type="submit" value="Envoyé"
                        data-wait="Merci pour votre commentaire" class="submit-button-2 w-button" /></form>
                <div class="w-form-done">
                    <div>Thank you! Your submission has been received!</div>
                </div>
                <div class="w-form-fail">
                    <div>Oops! Something went wrong while submitting the form.</div>
                </div>
            </div>
        </section>
       

    </body>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\resources\views/landing.blade.php ENDPATH**/ ?>