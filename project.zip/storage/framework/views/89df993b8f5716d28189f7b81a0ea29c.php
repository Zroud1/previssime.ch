<section class="section-8" id="section-2">
    <div class="div-block-111">
        <div class="div-block-112 second-page"></div>
    </div>
    <div class="text-block-70">Vérification d&#x27;identité</div>
    <div class="text-block-71">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
        laboris nisi ut aliquip ex ea commodo consequat.</div>
    <div class="form-block-2 second-page w-form" >
        <div class="div-block-173" style="display: flex;">
            <div class="input-first-form margin-2nd-page"><label for="name" class="field-label-3">Numéro AVS
                    <span class="text-span">*</span></label>
                <div class="div-block-127">

                    <img src="https://uploads-ssl.webflow.com/65129d80ea060cc3955c1aff/651aa7b89c9d9a09e7347aa6_picture-svgrepo-com%201%20(1).png" loading="lazy" sizes="(max-width: 479px) 100.00000762939453px, 130.98959350585938px" srcset="https://uploads-ssl.webflow.com/65129d80ea060cc3955c1aff/651aa7b89c9d9a09e7347aa6_picture-svgrepo-com%201%20(1)-p-500.png 500w, https://uploads-ssl.webflow.com/65129d80ea060cc3955c1aff/651aa7b89c9d9a09e7347aa6_picture-svgrepo-com%201%20(1).png 600w" alt="" class="image-51" />
                    <div>
                        <div class="text-block-79">Recto</div>
                        <div class="text-block-80">

                            <input type="file"   name="numeroAvsImage" id="numeroAvsImage" accept="image/*">
                            <span class="text-danger" id="numeroAvsImageError"></span>


                        </div>
                    </div>
                </div>
            </div>
            <div class="input-first-form _3rd-page"><label for="name" class="field-label-3">Caisse de pension
                    actuelle <span class="text-span">*</span></label>
                <div class="div-block-127">
                    <img src="https://uploads-ssl.webflow.com/65129d80ea060cc3955c1aff/651aa7b89c9d9a09e7347aa6_picture-svgrepo-com%201%20(1).png" loading="lazy" sizes="(max-width: 479px) 100.00000762939453px, 130.98959350585938px" srcset="https://uploads-ssl.webflow.com/65129d80ea060cc3955c1aff/651aa7b89c9d9a09e7347aa6_picture-svgrepo-com%201%20(1)-p-500.png 500w, https://uploads-ssl.webflow.com/65129d80ea060cc3955c1aff/651aa7b89c9d9a09e7347aa6_picture-svgrepo-com%201%20(1).png 600w" alt="" class="image-51" />
                    <div>
                        <div class="text-block-79">Verso</div>
                        <div class="text-block-80">
                            <input type="file"    name="caissePensionActuelleImage" id="caissePensionActuelleImage" accept="image/*">
                            <span class="text-danger" id="caissePensionActuelleImageError"></span>

                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
    <div class="text-block-81">Signature <span class="text-span-5">*</span></div>
    <div class="text-block-82">Veillez à faire une signature lisible et qui ressemble à celle figurant sur votre
        document d’identité. N’hésitez pas à recommencez si la signature n’est pas correctent réalisée du premier
        coup.</div>


    <div class="div-block-128" style="height: 225px">

        <div id="signature-pad"><canvas   id="sign"></canvas></div>

        <textarea id='output' name="signature" style="opacity:0; display: none"  readonly ></textarea>
        <a href="#" id="clearBtn"  >Effacer</a>
        <span class="text-danger" id="signatureError"></span>


    </div>
    <span id="outputError" class="text-danger" style="font-size: 20px"></span>

    <div class="div-block-115"></div>
    <div class="div-block-116">
        <a href="#" class="button-4 precedent w-button  " id="prev-btn2">Précédent</a>
        <a href="#" class="button-4 w-button " id="next-btn2">Suivant</a>
    </div>

</section>


<?php /**PATH C:\Users\02206\Desktop\project\resources\views/etaps-recuperer/second.blade.php ENDPATH**/ ?>