

<?php /**PATH C:\Users\LENOVO\Desktop\project\resources\views/layout/script.blade.php ENDPATH**/ ?>