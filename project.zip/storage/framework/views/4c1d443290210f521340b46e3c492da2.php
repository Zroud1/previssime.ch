

<?php /**PATH F:\24-10-2023\project\resources\views/layout/script.blade.php ENDPATH**/ ?>