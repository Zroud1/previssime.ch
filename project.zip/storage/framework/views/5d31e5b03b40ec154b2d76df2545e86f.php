

<?php /**PATH C:\Users\02206\Desktop\project\resources\views/layout/script.blade.php ENDPATH**/ ?>