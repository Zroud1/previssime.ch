

<?php /**PATH C:\Users\LENOVO\Desktop\25-10-2023\project\resources\views/layout/script.blade.php ENDPATH**/ ?>